/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fonteric_m12_pt1;

import java.util.Scanner;

/**
 *
 * @author ericfont
 */
public class FontEric_m12_pt1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner teclat = new Scanner(System.in);

        char matriu[][], jugadorActual;
        char guanyadors;
        int files, columnes, filesPintades, filesAux;
        int fitxa, contTorn = 0, contPartida = 0;
        int recompteHJ1, recompteHJ2;
        int recompteVJ1, recompteVJ2;
        int totalc = 0;

        boolean fiPartida = false;
        boolean pintaLinia, jugador1 = true;
        boolean partida = false;

        System.out.println("Com és diu el primer jugador?");
        jugadorActual = teclat.nextLine().charAt(0);
        System.out.println("Com és diu el segon jugador?");
        jugadorActual = teclat.nextLine().charAt(0);

        System.out.println("Introdueix les files: ");
        while (!teclat.hasNextInt()) {
            teclat.next();
            System.out.println("Error, ha de ser un int");
        }
        files = teclat.nextInt();

        totalc = totalc + files;

        System.out.println("Introdueix les columnes: ");
        while (!teclat.hasNextInt()) {
            teclat.next();
            System.out.println("Error, ha de ser un int");
        }
        columnes = teclat.nextInt();

        totalc = totalc * columnes;

        matriu = new char[files][columnes];

        //CREEM EL TAULER
        for (int i = 0; i < files; i++) {
            for (int j = 0; j < columnes; j++) {
                matriu[i][j] = ' ';
            }
        }

        System.out.println("");

        System.out.println("");
        System.out.println("COMENÇA EL JOC: ");
        System.out.println("--------------- ");
        System.out.println("");

        while (!fiPartida) {

            if (jugador1) {
                jugadorActual = 'X';
            } else {
                jugadorActual = '0';
            }

            filesPintades = files;
            filesAux = 0;
            pintaLinia = true;

            for (int i = 0; i < (files * 2) + 1; i++) {

                if (pintaLinia) {

                    System.out.printf("%2s", " ");
                    for (int j = 0; j < (columnes * 4) + 1; j++) {
                        System.out.print("-");
                    }
                    System.out.println("");
                    pintaLinia = false;

                } else {
                    System.out.printf("%2s", filesPintades);
                    for (int j = 0; j < columnes; j++) {
                        System.out.print("|" + " " + matriu[filesAux][j] + " ");
                    }
                    System.out.println("|");
                    pintaLinia = true;
                    filesAux++;
                    filesPintades--;
                }
            }

            System.out.print("  ");

            for (int j = 0; j < columnes; j++) {

                System.out.printf("%3d ", (j + 1));
            }

            //COMENÇEM A JUGAR
            System.out.println("");
            System.out.println("\njugador" + "(" + jugadorActual + ")" + ",matriu[1 - " + columnes + "]");

            System.out.println("Introdueix una fitxa a una columna: ");
            while (!teclat.hasNextInt()) {
                teclat.next();
                System.out.println("Error, ha de ser un int");
            }
            fitxa = teclat.nextInt() - 1;
            contTorn++;

            if (fitxa > columnes) {
                System.out.println("No pot ser tan gran!");
            }

            for (int j = matriu.length - 1; j >= 0; j--) {
                if (matriu[j][fitxa] == ' ') {
                    matriu[j][fitxa] = jugadorActual;

                    if (jugador1) {
                        jugador1 = false;
                    } else {
                        jugador1 = true;
                    }
                    break;

                }

            }

//            //COMPROBEM SI ESTA PLE
//            if (columnes == contTorn) {
//                System.out.println("Columnes plenes, escull un altre");
//            } else if (files == contTorn) {
//                System.out.println("Files plenes, escull un altre");
//            }
            //COMPROBEM ELS GUANYADORS HORITZONTALMENT
            recompteHJ1 = 0;
            recompteHJ2 = 0;

            for (int i = 0; i < matriu.length; i++) {
                for (int j = 0; j < matriu[i].length; j++) {

                    if (matriu[i][j] == jugadorActual) {
                        recompteHJ2 = 0;
                        recompteHJ1++;
                        if (recompteHJ1 >= 4) {
                            System.out.println("Guanyador: " + jugadorActual);
                            guanyadors = jugadorActual;

                            fiPartida = true;

                        }
                    } else if (matriu[i][j] == jugadorActual) {
                        recompteHJ1 = 0;
                        recompteHJ2++;
                        if (recompteHJ2 >= 4) {
                            System.out.println("Guanyador: " + jugadorActual);
                            guanyadors = jugadorActual;

                            fiPartida = true;

                        }
                    } else if (matriu[i][j] == ' ') {
                        recompteHJ2 = 0;
                        recompteHJ1 = 0;
                    }
                }
            }

            //COMPROBEM ELS GUANYADORS VERTICALMENT
            recompteVJ1 = 0;
            recompteVJ2 = 0;

            for (int i = 0; i < matriu[0].length; i++) {
                for (int j = 0; j < matriu.length; j++) {

                    if (matriu[j][i] == jugadorActual) {
                        recompteVJ2 = 0;
                        recompteVJ1++;
                        if (recompteVJ1 >= 4) {
                            System.out.println("Guanyador: " + jugadorActual);
                            guanyadors = jugadorActual;

                            fiPartida = true;
                        }
                    } else if (matriu[j][i] == jugadorActual) {
                        recompteVJ1 = 0;
                        recompteVJ2++;
                        if (recompteVJ2 >= 4) {
                            System.out.println("Guanyador: " + jugadorActual);
                            guanyadors = jugadorActual;

                            fiPartida = true;
                        }
                    } else if (matriu[j][i] == ' ') {
                        recompteVJ2 = 0;
                        recompteVJ1 = 0;
                    }
                }
            }

            //COMPROBEM L'EMPAT
            if (totalc == contTorn) {
                fiPartida = true;
                System.out.println("------");
                System.out.println("EMPAT!");
                System.out.println("------");
            }

            //fiPartida = true;
        }

        //Preguntem si vol jugar una altra partida
        System.out.println("Vols tornar a jugar?");
        System.out.println("1.Si\n2.No");
        int jugar = teclat.nextInt();
        teclat.nextLine();

        //En cas de que digui si torna a començar
        //En cas de que digui que no para
        if (jugar == 1) {
            fiPartida = false;
            contPartida++;
        } else if (jugar == 2) {
            fiPartida = true;
        }
    }    
}
   

